package com.androidtutorialshub.sqlitedatabaseexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DatabaseHelper db = new DatabaseHelper(this);

        // Inserting Contacts
        Log.d("Insert: ", "Inserting.");

        db.addEmployee(new Employee("Akanksha",    "9988998899"));
        db.addEmployee(new Employee(   "Lalit",  "888888888"));
        db.addEmployee(new Employee(   "Ayush",     "9876543210"));
        db.addEmployee(new Employee(   "Nitul",   "9977997799"));
        db.addEmployee(new Employee(   "Apolo",     "5816525555"));
        db.addEmployee(new Employee(   "Nikola",   "3322445500"));

        db.deleteEmployee(1);

        db.updateEmployee(5, "Claude", "000000000");

        // Reading all contacts
        Log.d("Reading: ", "Reading all Employee Records ..");
        List<Employee> employees = db.getAllEmployee();


         for (int i = 0; i < employees.size(); i++) {
             String log = "Employee Id: " + employees.get(i).getEmpId() +
                        " ,Employee Name: " + employees.get(i).getEmpName() +
                     " ,Employee Phone: " + employees.get(i).getEmpPhoneNo();

             Log.d("Name: ", log);
          }

    }
}

package com.example.luiscastaneda.calculatricedevoir;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    //On déclare toutes les variables dont on aura besoin
    Button button0;
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;
    Button buttonPlus;
    Button buttonMoins;
    Button buttonDiv;
    Button buttonMul;
    Button buttonRacine;
    Button buttonPercent;
    Button buttonUndivx;
    Button buttonPlusmoin;
    Button buttonC;
    Button buttonEgal;
    Button buttonPoint;
    EditText ecran;

    private double chiffre1 = 0.0;
    private double chiffre2 = 0.0;
    private boolean clicOperateur = false;
    private String operateur = "";
    private String str = "";
    private String nombre = "";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //On récupère tout les éléments de notre interface graphique grâce aux ID
        button0 = (Button) findViewById(R.id.button0);
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
        button5 = (Button) findViewById(R.id.button5);
        button6 = (Button) findViewById(R.id.button6);
        button7 = (Button) findViewById(R.id.button7);
        button8 = (Button) findViewById(R.id.button8);
        button9 = (Button) findViewById(R.id.button9);

        buttonPoint = (Button) findViewById(R.id.buttonPoint);
        buttonPlus = (Button) findViewById(R.id.buttonPlus);
        buttonMoins = (Button) findViewById(R.id.buttonMoins);
        buttonDiv = (Button) findViewById(R.id.buttonDivision);
        buttonMul = (Button) findViewById(R.id.buttonMultiplier);
        buttonRacine = (Button) findViewById(R.id.buttonRacine);
        buttonUndivx = (Button) findViewById(R.id.buttonUndivx);
        buttonPlusmoin = (Button) findViewById(R.id.buttonPlusmoin);
        buttonPercent = (Button) findViewById(R.id.buttonPercent);

        buttonC = (Button) findViewById(R.id.buttonC);
        buttonEgal = (Button) findViewById(R.id.buttonEgal);

        ecran = (EditText) findViewById(R.id.EditText01);

        //On déclare tous les boutons
        buttonPlus.setOnClickListener(this);
        buttonMoins.setOnClickListener(this);
        buttonDiv.setOnClickListener(this);
        buttonMul.setOnClickListener(this);
        buttonRacine.setOnClickListener(this);
        buttonUndivx.setOnClickListener(this);
        buttonPlusmoin.setOnClickListener(this);
        buttonPercent.setOnClickListener(this);
        buttonC.setOnClickListener(this);
        buttonEgal.setOnClickListener(this);
        buttonPoint.setOnClickListener(this);
        button0.setOnClickListener(this);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);
        button9.setOnClickListener(this);

    } // fin OnCreate

    public void onClick(View v){

        switch(v.getId()){

            case R.id.button0:
                str = "0";
                nombre += str;
                ecran.setText(nombre);
                break;
            case R.id.button1:
                str = "1";
                nombre += str;
                ecran.setText(nombre);
                break;
            case R.id.button2:
                str = "2";
                nombre += str;
                ecran.setText(nombre);
                break;
            case R.id.button3:
                str = "3";
                nombre += str;
                ecran.setText(nombre);
                break;
            case R.id.button4:
                str = "4";
                nombre += str;
                ecran.setText(nombre);
                break;
            case R.id.button5:
                str = "5";
                nombre += str;
                ecran.setText(nombre);
                break;
            case R.id.button6:
                str = "6";
                nombre += str;
                ecran.setText(nombre);
                break;
            case R.id.button7:
                str = "7";
                nombre += str;
                ecran.setText(nombre);
                break;
            case R.id.button8:
                str = "8";
                nombre += str;
                ecran.setText(nombre);
                break;
            case R.id.button9:
                str = "9";
                nombre += str;
                ecran.setText(nombre);
                break;
            case R.id.buttonPoint:
                str = ".";
                nombre += str;
                ecran.setText(nombre);
                break;

            case R.id.buttonPlus:
                if(TextUtils.isEmpty(ecran.getText().toString())){
                   break;
                }
                try {
                    chiffre1 = Double.parseDouble(nombre);
                } catch (NumberFormatException e){
                    Toast.makeText(this, "Erreur, nombre non valide", Toast.LENGTH_LONG).show();
                    clicOperateur = false;
                    chiffre1 = 0.0;
                    chiffre2 = 0.0;
                    operateur = "";
                    ecran.setText("");
                    nombre = "";
                    return;
                }
                clicOperateur = true;
                ecran.setText("+");
                operateur = "+";
                nombre = "";
                break;

            case R.id.buttonMoins:
                if(TextUtils.isEmpty(ecran.getText().toString())){
                    break;
                }

                try {
                    chiffre1 = Double.parseDouble(nombre);
                } catch (NumberFormatException e){
                    Toast.makeText(this, "Erreur, nombre non valide", Toast.LENGTH_LONG).show();
                    clicOperateur = false;
                    chiffre1 = 0.0;
                    chiffre2 = 0.0;
                    operateur = "";
                    ecran.setText("");
                    nombre = "";
                    return;
                }

                clicOperateur = true;
                ecran.setText("-");
                operateur = "-";
                nombre = "";
                break;

            case R.id.buttonMultiplier:
                if(TextUtils.isEmpty(ecran.getText().toString())){
                    break;
                }

                try {
                    chiffre1 = Double.parseDouble(nombre);
                } catch (NumberFormatException e){
                    Toast.makeText(this, "Erreur, nombre non valide", Toast.LENGTH_LONG).show();
                    clicOperateur = false;
                    chiffre1 = 0.0;
                    chiffre2 = 0.0;
                    operateur = "";
                    ecran.setText("");
                    nombre = "";
                    return;
                }

                clicOperateur = true;
                ecran.setText("*");
                operateur = "*";
                nombre = "";
                break;

            case R.id.buttonDivision:
                if(TextUtils.isEmpty(ecran.getText().toString())){
                    break;
                }

                try {
                    chiffre1 = Double.parseDouble(nombre);
                } catch (NumberFormatException e){
                    Toast.makeText(this, "Erreur, nombre non valide", Toast.LENGTH_LONG).show();
                    clicOperateur = false;
                    chiffre1 = 0.0;
                    chiffre2 = 0.0;
                    operateur = "";
                    ecran.setText("");
                    nombre = "";
                    return;
                }

                clicOperateur = true;
                ecran.setText("/");
                operateur = "/";
                nombre = "";
                break;

            case R.id.buttonRacine:
                if(TextUtils.isEmpty(ecran.getText().toString())){
                    break;
                }

                try {
                    chiffre1 = Double.parseDouble(nombre);
                } catch (NumberFormatException e){
                    Toast.makeText(this, "Erreur, nombre non valide", Toast.LENGTH_LONG).show();
                    clicOperateur = false;
                    chiffre1 = 0.0;
                    chiffre2 = 0.0;
                    operateur = "";
                    ecran.setText("");
                    nombre = "";
                    return;
                }

                clicOperateur = true;
                ecran.setText("√");
                operateur = "√";
                nombre = "";
                break;

            case R.id.buttonPlusmoin:
                if(TextUtils.isEmpty(ecran.getText().toString())){
                    break;
                }

                try {
                    chiffre1 = Double.parseDouble(nombre);
                } catch (NumberFormatException e){
                    Toast.makeText(this, "Erreur, nombre non valide", Toast.LENGTH_LONG).show();
                    clicOperateur = false;
                    chiffre1 = 0.0;
                    chiffre2 = 0.0;
                    operateur = "";
                    ecran.setText("");
                    nombre = "";
                    return;
                }

                clicOperateur = true;
                ecran.setText("+/-");
                operateur = "p";
                nombre = "";
                break;

            case R.id.buttonUndivx:
                if(TextUtils.isEmpty(ecran.getText().toString())){
                    break;
                }

                try {
                    chiffre1 = Double.parseDouble(nombre);
                } catch (NumberFormatException e){
                    Toast.makeText(this, "Erreur, nombre non valide", Toast.LENGTH_LONG).show();
                    clicOperateur = false;
                    chiffre1 = 0.0;
                    chiffre2 = 0.0;
                    operateur = "";
                    ecran.setText("");
                    nombre = "";
                    return;
                }

                clicOperateur = true;
                ecran.setText("1/x");
                operateur = "x";
                nombre = "";
                break;

            case R.id.buttonPercent:
                if(TextUtils.isEmpty(ecran.getText().toString())){
                    break;
                }

                try {
                    chiffre2 = Double.parseDouble(nombre);
                } catch (NumberFormatException e){
                    Toast.makeText(this, "Erreur, nombre non valide", Toast.LENGTH_LONG).show();
                    clicOperateur = false;
                    chiffre1 = 0.0;
                    chiffre2 = 0.0;
                    operateur = "";
                    ecran.setText("");
                    nombre = "";
                    return;
                }
                
                ecran.setText("%");

                if(operateur.equals("+")) {
                    chiffre1 = chiffre1 + (chiffre1 * chiffre2 * 0.01);
                    ecran.setText(String.valueOf(chiffre1));
                    nombre = ecran.getText().toString();
                }

                if(operateur.equals("-")) {
                    chiffre1 = chiffre1 - (chiffre1 * chiffre2 * 0.01);
                    ecran.setText(String.valueOf(chiffre1));
                    nombre = ecran.getText().toString();
                }

                if(operateur.equals("*")) {
                    chiffre1 = chiffre1 * chiffre2 * 0.01;
                    ecran.setText(String.valueOf(chiffre1));
                    nombre = ecran.getText().toString();
                }
                else break;
                clicOperateur = false;
                break;

            case R.id.buttonEgal:
                if(TextUtils.isEmpty(ecran.getText().toString())){
                    break;
                }

                calcul();
                clicOperateur = false;
                nombre = ecran.getText().toString();
                break;

            case R.id.buttonC:

                clicOperateur = false;
                chiffre1 = 0.0;
                chiffre2 = 0.0;
                operateur = "";
                ecran.setText("");
                nombre = "";
                break;

        } // fin switch
    } // fin onClick

    //Voici la méthode qui fait le calcul qui a été demandé par l'utilisateur
    private void calcul(){
        if(operateur.equals("+")){

            try {
                chiffre2 = Double.parseDouble(nombre);
            } catch (NumberFormatException e){
                Toast.makeText(this, "Erreur, nombre non valide", Toast.LENGTH_LONG).show();
                clicOperateur = false;
                chiffre1 = 0.0;
                chiffre2 = 0.0;
                operateur = "";
                ecran.setText("");
                nombre = "";
                return;
            }

            chiffre1 = chiffre1 + chiffre2;
            ecran.setText(String.valueOf(chiffre1));
            nombre = "";
        }

        if(operateur.equals("-")){

            try {
                chiffre2 = Double.parseDouble(nombre);
            } catch (NumberFormatException e){
                Toast.makeText(this, "Erreur, nombre non valide", Toast.LENGTH_LONG).show();
                clicOperateur = false;
                chiffre1 = 0.0;
                chiffre2 = 0.0;
                operateur = "";
                ecran.setText("");
                nombre = "";
                return;
            }

            chiffre1 = chiffre1 - chiffre2;
            ecran.setText(String.valueOf(chiffre1));
            nombre = "";
        }

        if(operateur.equals("*")){

            try {
                chiffre2 = Double.parseDouble(nombre);
            } catch (NumberFormatException e){
                Toast.makeText(this, "Erreur, nombre non valide", Toast.LENGTH_LONG).show();
                clicOperateur = false;
                chiffre1 = 0.0;
                chiffre2 = 0.0;
                operateur = "";
                ecran.setText("");
                nombre = "";
                return;
            }

            chiffre1 = chiffre1 * chiffre2;
            ecran.setText(String.valueOf(chiffre1));
            nombre = "";
        }

        if(operateur.equals("/")){

            try {
                chiffre2 = Double.parseDouble(nombre);
            } catch (NumberFormatException e){
                Toast.makeText(this, "Erreur, nombre non valide", Toast.LENGTH_LONG).show();
                clicOperateur = false;
                chiffre1 = 0.0;
                chiffre2 = 0.0;
                operateur = "";
                ecran.setText("");
                nombre = "";
                return;
            }
            
            if(chiffre2 == 0){
                Toast.makeText(this, "Erreur, division par zero", Toast.LENGTH_LONG).show();
                clicOperateur = false;
                chiffre1 = 0.0;
                chiffre2 = 0.0;
                operateur = "";
                ecran.setText("");
                nombre = "";
                return;
            }
            chiffre1 = chiffre1 / chiffre2;
            ecran.setText(String.valueOf(chiffre1));
            nombre = "";
        }

        if(operateur.equals("√")) {

                chiffre1 = Math.sqrt(chiffre1);
                ecran.setText(String.valueOf(chiffre1));
                nombre = "";

        }

         if(operateur.equals("x")){

                 chiffre1 = Math.pow(chiffre1,-1.0);
                 ecran.setText(String.valueOf(chiffre1));
                 nombre = "";

        }

        if(operateur.equals("p")){

                chiffre1 = chiffre1 * -1.0;
                ecran.setText(String.valueOf(chiffre1));
                nombre = "";

        }
    } // fin calcule
} // fin classe

package com.example.luiscastaneda.villes_province;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    private Spinner spinner2;
    private Spinner spin;
    private ArrayAdapter aa;
    private ImageView img;
    String[] countryNames={"Ontario","Québec","Nouvelle écosse","Nouveau Brunswick","Manitoba","Colombie Britanique"};
    int flags[] = {R.drawable.ontario, R.drawable.quebec, R.drawable.nouvelleecose, R.drawable.nouveaubruswick,
            R.drawable.manitoba, R.drawable.colombiebritanique};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Getting the instance of Spinner and applying OnItemSelectedListener on it
        spin = (Spinner) findViewById(R.id.simpleSpinner);
        spin.setOnItemSelectedListener(this);

        CustomAdapter customAdapter = new CustomAdapter(getApplicationContext(),flags,countryNames);
        spin.setAdapter(customAdapter);

         img = (ImageView) findViewById(R.id.image);
        spinner2 = (Spinner) findViewById(R.id.spinner2);

    } // onCreate

    //Performing action onItemSelected and onNothing selected
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position,long id) {
      //  Toast.makeText(getApplicationContext(), countryNames[position], Toast.LENGTH_LONG).show();

        if(countryNames[position].equals("Québec")){

            img.setImageResource(R.drawable.quebecf);
            List<String> list = new ArrayList<String>();
            list.add("Montréal"); list.add("Québec"); list.add("Laval");
            list.add("Gatineau"); list.add("Sherbrooke"); list.add("Lévis"); list.add("Longueuil");
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,list);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner2.setAdapter(dataAdapter);

        }

        if(countryNames[position].equals("Ontario")){

            img.setImageResource(R.drawable.ontariof);
            List<String> list = new ArrayList<String>();
            list.add("Brampton"); list.add("Cambridge"); list.add("Cornwall");
            list.add("Hamilton"); list.add("Kingston"); list.add("London");  list.add("Ottawa"); list.add("Windsor");
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,list);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner2.setAdapter(dataAdapter);

        }

        if(countryNames[position].equals("Nouvelle écosse")){

            img.setImageResource(R.drawable.nouvelleecossef);
            List<String> list = new ArrayList<String>();
            list.add("Halifax"); list.add("Sydney"); list.add("Dartmouth");
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,list);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner2.setAdapter(dataAdapter);

        }

        if(countryNames[position].equals("Nouveau Brunswick")){

            img.setImageResource(R.drawable.nouveaubrunswickf);
            List<String> list = new ArrayList<String>();
            list.add("Edmundston"); list.add("Fredericton"); list.add("Moncton");
            list.add("Saint-Jean"); list.add("Campbellton"); list.add("Dieppe");
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,list);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner2.setAdapter(dataAdapter);

        }

        if(countryNames[position].equals("Manitoba")){

            img.setImageResource(R.drawable.manitobaf);
            List<String> list = new ArrayList<String>();
            list.add("Winnipeg"); list.add("Thompson"); list.add("Brandon");
            list.add("Dauphin"); list.add("Selkirk"); list.add("Steinbach");
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,list);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner2.setAdapter(dataAdapter);

        }

        if(countryNames[position].equals("Colombie Britanique")){

            img.setImageResource(R.drawable.colombiebritaniquef);
            List<String> list = new ArrayList<String>();
            list.add("Vancouver"); list.add("Vernon"); list.add("Victoria"); list.add("Burnaby");
            list.add("Surrey"); list.add("Prince george"); list.add("Penticton");  list.add("Mission"); list.add("Nelson");
            list.add("Kimberley"); list.add("Fernie"); list.add("Colwood");  list.add("Castlegar"); list.add("Armstrong");
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,list);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner2.setAdapter(dataAdapter);

        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }
}
